import 'dart:io';

import 'package:chewie/chewie.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

// App ki apni storage limit: 100 GB
const int kQuotaBytes = 100 * 1024 * 1024 * 1024;

void main() {
  runApp(const VideoVaultApp());
}

class VideoVaultApp extends StatelessWidget {
  const VideoVaultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Secret',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.deepPurple,
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      home: const HomePage(),
    );
  }
}

String formatBytes(int bytes) {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  double size = bytes.toDouble();
  int i = 0;
  while (size >= 1024 && i < units.length - 1) {
    size /= 1024;
    i++;
  }
  return '${size.toStringAsFixed(i == 0 ? 0 : 2)} ${units[i]}';
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Directory? _vaultDir;
  List<File> _videos = [];
  int _usedBytes = 0;
  bool _loading = true;
  bool _importing = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(base.path, 'videos'));
    if (!await dir.exists()) await dir.create(recursive: true);
    _vaultDir = dir;
    await _refresh();
  }

  Future<void> _refresh() async {
    final dir = _vaultDir;
    if (dir == null) return;
    final files = dir.listSync().whereType<File>().toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    int total = 0;
    for (final f in files) {
      total += await f.length();
    }
    if (!mounted) return;
    setState(() {
      _videos = files;
      _usedBytes = total;
      _loading = false;
    });
  }

  Future<void> _importVideos() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.video,
      allowMultiple: true,
    );
    if (result == null) return;

    setState(() => _importing = true);
    int added = 0;
    for (final picked in result.files) {
      final path = picked.path;
      if (path == null) continue;
      final src = File(path);
      final size = await src.length();
      if (_usedBytes + size > kQuotaBytes) {
        _toast('100 GB limit poori ho gayi. Kuch videos delete karein.');
        break;
      }
      final name = p.basename(path);
      var dest = File(p.join(_vaultDir!.path, name));
      if (await dest.exists()) {
        dest = File(p.join(_vaultDir!.path,
            '${DateTime.now().millisecondsSinceEpoch}_$name'));
      }
      await src.copy(dest.path);
      _usedBytes += size;
      added++;
    }
    // file_picker ki temporary copy hata do taaki jagah na ghire
    await FilePicker.platform.clearTemporaryFiles();
    await _refresh();
    if (!mounted) return;
    setState(() => _importing = false);
    if (added > 0) _toast('$added video add ho gayi');
  }

  Future<void> _delete(File f) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Video delete karein?'),
        content: Text(p.basename(f.path)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Nahi')),
          FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true) {
      await f.delete();
      await _refresh();
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final fraction = (_usedBytes / kQuotaBytes).clamp(0.0, 1.0);
    return Scaffold(
      appBar: AppBar(title: const Text('Secret')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${formatBytes(_usedBytes)} used  •  '
                  '${formatBytes(kQuotaBytes - _usedBytes)} khali (100 GB me se)',
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(value: fraction, minHeight: 8),
                if (_importing)
                  const Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Row(children: [
                      SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2)),
                      SizedBox(width: 12),
                      Text('Video copy ho rahi hai...'),
                    ]),
                  ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _videos.isEmpty
                    ? const Center(
                        child: Text('Abhi koi video nahi.\nNeeche + dabakar add karein.',
                            textAlign: TextAlign.center))
                    : ListView.separated(
                        itemCount: _videos.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final f = _videos[i];
                          return ListTile(
                            leading: const Icon(Icons.play_circle_fill, size: 40),
                            title: Text(p.basenameWithoutExtension(f.path),
                                maxLines: 2, overflow: TextOverflow.ellipsis),
                            subtitle: Text(formatBytes(f.lengthSync())),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () => _delete(f),
                            ),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => PlayerPage(file: f)),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _importing ? null : _importVideos,
        icon: const Icon(Icons.add),
        label: const Text('Video add karein'),
      ),
    );
  }
}

class PlayerPage extends StatefulWidget {
  final File file;
  const PlayerPage({super.key, required this.file});

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late VideoPlayerController _video;
  ChewieController? _chewie;
  String? _error;

  @override
  void initState() {
    super.initState();
    _setup();
  }

  Future<void> _setup() async {
    try {
      _video = VideoPlayerController.file(widget.file);
      await _video.initialize();
      _chewie = ChewieController(
        videoPlayerController: _video,
        autoPlay: true,
        allowFullScreen: true,
        allowPlaybackSpeedChanging: true,
      );
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => _error = 'Video play nahi ho paayi: $e');
    }
  }

  @override
  void dispose() {
    _chewie?.dispose();
    _video.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(p.basenameWithoutExtension(widget.file.path))),
      body: Center(
        child: _error != null
            ? Padding(padding: const EdgeInsets.all(24), child: Text(_error!))
            : _chewie == null
                ? const CircularProgressIndicator()
                : Chewie(controller: _chewie!),
      ),
    );
  }
}
