# Secret (Android)

Apni videos ko phone me import karke save karne aur chalane wala app. Koi server ya paisa nahi lagta.

## Kaise chalayein

1. Flutter install karein: https://docs.flutter.dev/get-started/install
2. Naya project banayein (Android folder apne aap ban jayega):
   ```
   flutter create video_vault
   ```
3. Is folder ki `pubspec.yaml` aur `lib/main.dart` ko naye project me replace kar dein.
4. Phone USB se jodein (USB debugging ON) aur chalayein:
   ```
   flutter pub get
   flutter run
   ```
5. APK banane ke liye:
   ```
   flutter build apk --release
   ```
   File yahan milegi: `build/app/outputs/flutter-apk/app-release.apk`

## Zaroori setting

`android/app/build.gradle` me `minSdkVersion` ko **21** ya usse upar rakhein (video_player ke liye).

## App ka naam "Secret" (phone ke icon ke neeche)

`android/app/src/main/AndroidManifest.xml` kholein aur `<application` wali line me label badal dein:

```
android:label="Secret"
```

## Features

- Video import (ek saath kai videos)
- App ke andar copy hota hai, isliye original delete bhi ho jaye to video bachi rahegi
- 100 GB limit ka storage bar (kitna use hua, kitna khali)
- Player: play/pause, seek, fullscreen, speed
- Video delete

## Dhyan rahe

- 100 GB tabhi bharega jab phone me itni jagah ho. Phone ki asli khali memory Settings > Storage me dekhein.
- Import karte waqt video copy hoti hai, to utni hi extra jagah chahiye hogi jab tak original rakhi hai.
- Videos sirf isi phone me rahengi. App uninstall karne par ya phone kho jane par videos chali jayengi, isliye zaroori videos ka backup rakhein.
